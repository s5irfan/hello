<html>
<head>
	<title>Stubbing</title>
</head>
<body>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
	// Include Database Connection:
	// echo "start";
	include 'db-connection.php';
?>

<table width="100%" border="1px" cellpadding="5" cellspacing="0">	
<thead>
	<tr>
		<th>FORM_ID</th>
		<th>COURSE_ID</th>
		<th>SECTION</th>
		<th>APPLICATION_TERM</th>
		<th>TA_RANKING</th>
	</tr>
</thead>
<tbody>
		<?php
			mysqli_set_charset($todoAppMySQLConnection, 'utf8');
			$query_ListAllforms = "SELECT * FROM form;";
			$result_Allform = mysqli_query($todoAppMySQLConnection, $query_ListAllforms);
			// echo "The following all applications in the form table.";
			while($single_applicant = mysqli_fetch_assoc($result_Allform)) {
					$emparray = array();
			    	$emparray[] = $single_applicant['COURSES_APPLIED'];
			    	$arr = $emparray[0]
					?>
					<?php
					$found=false;
					$rank = 1;
					$course = "";
					// echo $course;
					for ($i = 0; $i < strlen($arr); $i++){
						if ($arr[$i]==',' or $arr[$i]=='}')
						{
							$course_id = "";
							$section = "";
							$find_under = false;
							for ($j = 0; $j < strlen($course); $j++){
								if ($find_under)
								{
									$section = $section . $course[$j];
								}
								if ($course[$j] == '-')
								{
									$find_under = true;
								}
								if ($find_under == false)
								{
									$course_id = $course_id . $course[$j];
								}
							}

							$f_id = $single_applicant['FORM_ID'];
							$a_t = $single_applicant['APPLICATION_TERM'];
							$course = "'" . $course;
							$course = $course ."'";
							$query = "
							INSERT INTO `FORM_RELATIONAL` (`FORM_ID`,`COURSE_ID`,`SECTION`,`APPLICATION_TERM`,`TA_RANKING`)
							VALUES ('$f_id','$course_id','$section','$a_t','$rank');
							";
							// echo $query;
							// mysqli_query($todoAppMySQLConnection, $query);
							echo '<tr>';
							echo '<td>'.$f_id . '</td>' ;
					    	echo '<td>'.$course_id . '</td>' ;
					    	echo '<td>'.$section . '</td>' ;
	   						echo '<td>' . $a_t . '</td>' ;
	   						echo '<td>' . $rank . '</td>' ;
							echo '</tr>';
							$found = false;
							$rank = $rank + 1;
							$course = "";
						}
						if  ($found)
						{
							$course = $course . $arr[$i];
						}
					    if ($arr[$i]==':')
					    {
					    	$course = $course;
					    	$found = true;
					    }
					}
			    }
		?>
</tbody>
</table>
</body>
</html>


