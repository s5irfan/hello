<html>
<head>
	<title>Stubbing</title>
</head>
<body>
<table width="100%" border="1px" cellpadding="5" cellspacing="0">	
<thead>
	<tr>
		<th>COURSE_ID</th>
		<th>SECTION</th>
		<th>TERM</th>
		<th>DESCRIPTION</th>
		<th>ENROLLMENT_CAPACITY</th>
		<th>TITLE</th>
		<th>LAB</th>
		<th>TUTORIAL</th>
		<th>NEEDS_TA</th>
	</tr>
</thead>
<tbody>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
	// Include Database Connection:
	// echo "start";
	include 'db-connection.php';
	// echo "successful";
	$add_course_data = "
		
	INSERT INTO course_section (COURSE_ID, SECTION, TERM, DESCRIPTION, ENROLLMENT_CAPACITY, TITLE, LAB,TUTORIAL, NEEDS_TA) VALUES
	('MSCI121', 'LEC 001', 1161, 'This is an introduction to programming.', '80', 'Introduction to Computer Programming', True, False, True),
	('MSCI131', 'LEC 001', 1161, 'This course is super fun.', '85', 'Work Design and Facilities Planning', True, True, True),
	('MSCI211', 'ARG 081', 1161, 'This course teaches the basics of Orginizaional Behaviour.', '90', 'Organizational Behaviour', True, True, True),
	('MSCI333', 'ARG 081', 1161, 'This course is a lot of work.', '90', 'Organizational Behaviour', True, True, True),
	('MSCI261', 'LEC 001', 1165, 'Introductory Finance: time value of money, cash flow analysis. Investment evaluation methods: present worth, annual worth and internal rate of return.', '80', 'Engineering Economics: Financial Management for Engineers', True, True, True),
('MSCI261', 'LEC 001', 1169, 'Introductory Finance: time value of money, cash flow analysis. Investment evaluation methods: present worth, annual worth and internal rate of return.', '80', 'Engineering Economics: Financial Management for Engineers', True, True, True),
('MSCI311', 'LEC 002', 1161, 'The focus of this course is on the procedures and variables involved in the design and redesign of organizations.', '80', 'Organizational Design and Technology', True, True, True),
('MSCI311', 'LEC 001', 1165, 'The focus of this course is on the procedures and variables involved in the design and redesign of organizations.', '80', 'Organizational Design and Technology', True, True, True),
('MSCI311', 'LEC 003', 1169, 'The focus of this course is on the procedures and variables involved in the design and redesign of organizations.', '80', 'Organizational Design and Technology', True, True, True),
('MSCI331', 'LEC 001', 1161, 'This first course in optimization uses a quantitative approach to problem solving involving, mathematical modelling and formulations, solution methods, and output analysis.', '80', 'Introduction to Optimization', True, True, True),
('MSCI331', 'LEC 002', 1165, 'This first course in optimization uses a quantitative approach to problem solving involving, mathematical modelling and formulations, solution methods, and output analysis.', '80', 'Introduction to Optimization', True, True, True),
('MSCI331', 'LEC 003', 1169, 'This first course in optimization uses a quantitative approach to problem solving involving, mathematical modelling and formulations, solution methods, and output analysis.', '80', 'Introduction to Optimization', True, True, True),
('MSCI334', 'LEC 001', 1161, 'This course exposes students to production planning and inventory control approaches in industrial and service systems.', '80', 'Operations Planning and Inventory Control', True, True, True),
('MSCI334', 'LEC 002', 1165, 'This course exposes students to production planning and inventory control approaches in industrial and service systems.', '80', 'Operations Planning and Inventory Control', True, True, True),
('MSCI334', 'LEC 001', 1169, 'This course exposes students to production planning and inventory control approaches in industrial and service systems.', '80', 'Operations Planning and Inventory Control', True, True, True),
('MSCI423', 'LEC 001', 1161, 'This course examines technical and organizational aspects of managing new product and process innovation.', '80', 'Managing New Product and Process Innovation', True, True, True),
('MSCI423', 'LEC 002', 1165, 'This course examines technical and organizational aspects of managing new product and process innovation.', '80', 'Managing New Product and Process Innovation', True, True, True),
('MSCI423', 'LEC 003', 1169, 'This course examines technical and organizational aspects of managing new product and process innovation.', '80', 'Managing New Product and Process Innovation', True, True, True),
('MSCI431', 'LEC 001', 1161, 'Introduction to Operations Research models and methods for problems with random, stochastic and probabilistic components. ', '80', 'Stochastic Models and Methods', True, True, True),
('MSCI431', 'LEC 002', 1165, 'Introduction to Operations Research models and methods for problems with random, stochastic and probabilistic components. ', '80', 'Stochastic Models and Methods', True, True, True),
('MSCI431', 'LEC 003', 1169, 'Introduction to Operations Research models and methods for problems with random, stochastic and probabilistic components. ', '80', 'Stochastic Models and Methods', True, True, True),
('MSCI432', 'LEC 001', 1161, 'Introduction to management, planning, and control decisions in manufacturing and service settings using quantitative approaches. ', '80', 'Production and Service Operations Management', True, True, True);

	";
		//echo $add_course_data;
	mysqli_query($todoAppMySQLConnection, $add_course_data);
	$add_intructor = "
		INSERT INTO instructors (FIRST_NAME, LAST_NAME) VALUES 
		(1,'Kejia','Zhu'),
		(2,'Olga','Vechtomova'),
		(3,'Mark','Smucker'),
		(4,'Frank','Safayeni'),
		(5,'Mehrdad','Pirnia'),
		(6,'Selcuk','Onay'),
		(7,'Jatin','Nathwani'),
		(8,'Ken','McKay'),
		(9,'Benny','Mantin');
	";
	mysqli_query($todoAppMySQLConnection, $add_intructor);
	$add_taught = "
		INSERT INTO taught_section(COURSE_ID, SECTION, TERM, INSTRUCTOR_ID) VALUES
		('MSCI121', 'LEC 001', 1161, 1),
		('MSCI131', 'LEC 001', 1161, 2),
		('MSCI211', 'ARG 081', 1161, 3);
	";
	mysqli_query($todoAppMySQLConnection, $add_taught);
		// Query db for all tasks:
		$query_ListAllcourse = "SELECT * FROM course_section;";
		$result_Allcourse = mysqli_query($todoAppMySQLConnection, $query_ListAllcourse);
		// echo "The following courses are in the course_section table.";
		while($singleCourse = mysqli_fetch_assoc($result_Allcourse)) {
			    	echo '<tr>';
			    	echo '<td>'.$singleCourse['COURSE_ID'] . '</td>' ;
			    	echo '<td>'.$singleCourse['SECTION'] . '</td>' ;
			    	echo '<td>'.$singleCourse['TERM'] . '</td>' ;
			    	echo '<td>'.$singleCourse['DESCRIPTION'] . '</td>' ;
			    	echo '<td>'.$singleCourse['ENROLLMENT_CAPACITY'] . '</td>' ;
			    	echo '<td>'.$singleCourse['TITLE'] . '</td>' ;
			    	echo '<td>'.$singleCourse['LAB'] . '</td>' ;
			    	echo '<td>'.$singleCourse['TUTORIAL'] . '</td>' ;
			    	echo '<td>'.$singleCourse['NEEDS_TA'] . '</td>' ;
			    	echo '</tr>';
			    }
		?>
		</tbody>
	</table>

<table width="100%" border="1px" cellpadding="5" cellspacing="0">	
<thead>
	<tr>
		<th>FORM_ID</th>
		<th>USER_ID</th>
		<th>APPLICATION_TERM</th>
		<th>STUDENT_ID</th>
		<th>LAST_NAME</th>
		<th>FIRST_NAME</th>
		<th>UW_USER_ID</th>
		<th>EMAIL</th>
		<th>PHONE</th>
		<th>CITIZENSHIP</th>
		<th>PERMIT_EXPIRY</th>
		<th>DEPARTMENT</th>
		<th>CURRENT_PROGRAM</th>
		<th>IS_FULL_TIME</th>
		<th>IS_PART_TIME</th>
		<th>EXPECTATIONS</th>
		<th>NEXT_ACADEMIC_TERM</th>
		<th>TA_POS_PREV_WINTER</th>
		<th>TA_POS_PREV_SPRING</th>
		<th>TA_POS_PREV_FALL</th>
		<th>RELEVANT_COURSES</th>
		<th>COURSES_APPLIED</th>
		<th>COURSES_NOT_QUALIFIED</th>
		<th>RELEVANT_EXPERIENCE</th>
		<th>APPLICATION_DATE</th>
		<th>GA_COMMENTS</th>
		<th>GA_VALIDATION</th>
		<th>ACCEPT_REJECT</th>
	</tr>
</thead>
<tbody>
		<?php
		$add_form_data = "
		INSERT INTO `form` (`FORM_ID`, `USER_ID`, `APPLICATION_TERM`, `STUDENT_ID`, `LAST_NAME`, `FIRST_NAME`, `UW_USER_ID`, `EMAIL`, `PHONE`, `CITIZENSHIP`, `PERMIT_EXPIRY`, `DEPARTMENT`, `CURRENT_PROGRAM`, `IS_FULL_TIME`, `IS_PART_TIME`, `EXPECTATIONS`, `NEXT_ACADEMIC_TERM`, `TA_POS_PREV_WINTER`, `TA_POS_PREV_SPRING`, `TA_POS_PREV_FALL`, `RELEVANT_COURSES`, `COURSES_APPLIED`, `COURSES_NOT_QUALIFIED`, `RELEVANT_EXPERIENCE`, `APPLICATION_DATE`, `GA_COMMENTS`, `GA_VALIDATION`, `ACCEPT_REJECT`) VALUES
		(1, 999, '1169', 20270951, 'KAN', 'JOHNSON', 'j2kan', 'j2kan@uwaterloo.ca', '416-500-1234' ,'Canadian', 'no need', 'Management Sciences', 'PHD', 1, 0, 1, 'Term 3', 'MSCI211', 'MSCI311', 'MSCI444', 'MSCI555, MSCI603', '{1:MSCI240-LEC 001, 2:MSCI444-LEC 001, 3:MSCI121-LEC 001, 4:MSCI342-LEC 002}' , 'MSCI100', 'Previous experience as a TA', '2016-11-04 08:21:26', NULL, NULL, 0);
		";
			mysqli_query($todoAppMySQLConnection, $add_form_data);
			// echo $add_form_data;
			$query_ListAllforms = "SELECT * FROM form;";
			$result_Allform = mysqli_query($todoAppMySQLConnection, $query_ListAllforms);
			// echo "The following all applications in the form table.";
			while($single_applicant = mysqli_fetch_assoc($result_Allform)) {
			    	echo '<tr>';
			    	echo '<td>'.$single_applicant['FORM_ID'] . '</td>' ;
			    	echo '<td>'.$single_applicant['USER_ID'] . '</td>' ;
			    	echo '<td>'.$single_applicant['APPLICATION_TERM'] . '</td>' ;
			    	echo '<td>'.$single_applicant['STUDENT_ID'] . '</td>' ;
			    	echo '<td>'.$single_applicant['LAST_NAME'] . '</td>' ;
			    	echo '<td>'.$single_applicant['FIRST_NAME'] . '</td>' ;
			    	echo '<td>'.$single_applicant['UW_USER_ID'] . '</td>' ;
			    	echo '<td>'.$single_applicant['EMAIL'] . '</td>' ;
			    	echo '<td>'.$single_applicant['PHONE'] . '</td>' ;
			    	echo '<td>'.$single_applicant['CITIZENSHIP'] . '</td>' ;
			    	echo '<td>'.$single_applicant['PERMIT_EXPIRY'] . '</td>' ;
			    	echo '<td>'.$single_applicant['DEPARTMENT'] . '</td>' ;
			    	echo '<td>'.$single_applicant['CURRENT_PROGRAM'] . '</td>' ;
			    	echo '<td>'.$single_applicant['IS_FULL_TIME'] . '</td>' ;
			    	echo '<td>'.$single_applicant['IS_PART_TIME'] . '</td>' ;
			    	echo '<td>'.$single_applicant['EXPECTATIONS'] . '</td>' ;
			    	echo '<td>'.$single_applicant['NEXT_ACADEMIC_TERM'] . '</td>' ;
			    	echo '<td>'.$single_applicant['TA_POS_PREV_WINTER'] . '</td>' ;
			    	echo '<td>'.$single_applicant['TA_POS_PREV_SPRING'] . '</td>' ;
			    	echo '<td>'.$single_applicant['TA_POS_PREV_FALL'] . '</td>' ;
			    	echo '<td>'.$single_applicant['RELEVANT_COURSES'] . '</td>' ;
			    	echo '<td>'.$single_applicant['COURSES_APPLIED'] . '</td>' ;
			    	echo '<td>'.$single_applicant['COURSES_NOT_QUALIFIED'] . '</td>' ;
			    	echo '<td>'.$single_applicant['RELEVANT_EXPERIENCE'] . '</td>' ;
			    	echo '<td>'.$single_applicant['APPLICATION_DATE'] . '</td>' ;
			    	echo '<td>'.$single_applicant['GA_COMMENTS'] . '</td>' ;
			    	echo '<td>'.$single_applicant['GA_VALIDATION'] . '</td>' ;
			    	echo '<td>'.$single_applicant['ACCEPT_REJECT'] . '</td>' ;
			    	echo '</tr>';
			    }
		include 'integrate_downstream.php';
		?>
	</tbody>
</table>
</body>
</html>


