<html>
<head>
	<title>form</title>
</head>
<body>
<table width="100%" border="1px" cellpadding="5" cellspacing="0">	
<thead>
	<tr>
		<th>FORM_ID</th>
		<th>USER_ID</th>
		<th>APPLICATION_TERM</th>
		<th>STUDENT_ID</th>
		<th>LAST_NAME</th>
		<th>FIRST_NAME</th>
		<th>UW_USER_ID</th>
		<th>CITIZENSHIP</th>
		<th>PERMIT_EXPIRY</th>
		<th>DEPARTMENT</th>
		<th>CURRENT_PROGRAM</th>
		<th>IS_FULL_TIME</th>
		<th>IS_PART_TIME</th>
		<th>EXPECTATIONS</th>
		<th>NEXT_ACADEMIC_TERM</th>
		<th>TA_POS_PREV_WINTER</th>
		<th>TA_POS_PREV_SPRING</th>
		<th>TA_POS_PREV_FALL</th>
		<th>RELEVANT_COURSES</th>
		<th>COURSES_APPLIED</th>
		<th>COURSES_NOT_QUALIFIED</th>
		<th>RELEVANT_EXPERIENCE</th>
		<th>APPLICATION_DATE</th>
		<th>GA_COMMENTS</th>
		<th>GA_VALIDATION</th>
		<th>ACCEPT_REJECT</th>
	</tr>
</thead>
<tbody>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
	// Include Database Connection:
	// echo "start";
	include 'db-connection.php';
	// echo "successful";
		// Query db for all tasks:
		$query_ListAllforms = "SELECT * FROM form;";
			$result_Allform = mysqli_query($todoAppMySQLConnection, $query_ListAllforms);
			// echo "The following all applications in the form table.";
			while($single_applicant = mysqli_fetch_assoc($result_Allform)) {
			    	echo '<tr>';
			    	echo '<td>'.$single_applicant['FORM_ID'] . '</td>' ;
			    	echo '<td>'.$single_applicant['USER_ID'] . '</td>' ;
			    	echo '<td>'.$single_applicant['APPLICATION_TERM'] . '</td>' ;
			    	echo '<td>'.$single_applicant['STUDENT_ID'] . '</td>' ;
			    	echo '<td>'.$single_applicant['LAST_NAME'] . '</td>' ;
			    	echo '<td>'.$single_applicant['FIRST_NAME'] . '</td>' ;
			    	echo '<td>'.$single_applicant['UW_USER_ID'] . '</td>' ;
			    	echo '<td>'.$single_applicant['CITIZENSHIP'] . '</td>' ;
			    	echo '<td>'.$single_applicant['PERMIT_EXPIRY'] . '</td>' ;
			    	echo '<td>'.$single_applicant['DEPARTMENT'] . '</td>' ;
			    	echo '<td>'.$single_applicant['CURRENT_PROGRAM'] . '</td>' ;
			    	echo '<td>'.$single_applicant['IS_FULL_TIME'] . '</td>' ;
			    	echo '<td>'.$single_applicant['IS_PART_TIME'] . '</td>' ;
			    	echo '<td>'.$single_applicant['EXPECTATIONS'] . '</td>' ;
			    	echo '<td>'.$single_applicant['NEXT_ACADEMIC_TERM'] . '</td>' ;
			    	echo '<td>'.$single_applicant['TA_POS_PREV_WINTER'] . '</td>' ;
			    	echo '<td>'.$single_applicant['TA_POS_PREV_SPRING'] . '</td>' ;
			    	echo '<td>'.$single_applicant['TA_POS_PREV_FALL'] . '</td>' ;
			    	echo '<td>'.$single_applicant['RELEVANT_COURSES'] . '</td>' ;
			    	echo '<td>'.$single_applicant['COURSES_APPLIED'] . '</td>' ;
			    	echo '<td>'.$single_applicant['COURSES_NOT_QUALIFIED'] . '</td>' ;
			    	echo '<td>'.$single_applicant['RELEVANT_EXPERIENCE'] . '</td>' ;
			    	echo '<td>'.$single_applicant['APPLICATION_DATE'] . '</td>' ;
			    	echo '<td>'.$single_applicant['GA_COMMENTS'] . '</td>' ;
			    	echo '<td>'.$single_applicant['GA_VALIDATION'] . '</td>' ;
			    	echo '<td>'.$single_applicant['ACCEPT_REJECT'] . '</td>' ;
			    	echo '</tr>';
			    }
		?>
		</tbody>
	</table>
</body>
</html>


