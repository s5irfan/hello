<?php
 
//======================================================================
// DATABASE LOGIN INFO
//======================================================================
//Error display
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// Local Database Connection Details:
$local_host = "localhost";
$local_username = "root";
$local_password = "root";
$local_databaseName = "team2";
#team 2 below
#$local_databaseName = "team-1-course-instructor-data";
// Production Database Connection Details: team 2 
$remote_host = "us-cdbr-iron-east-04.cleardb.net";
$remote_username = "b7477cfe9612d6";
$remote_password = "81cd2fbd";
$remote_databaseName = "heroku_728cf8cd2f74267";
//======================================================================
// DATABASE CONNECTION
// To use this connection on other php files add "include 'db-connection.php';" to sc top of the page.
//======================================================================
$possibleLocalhosts = array('127.0.0.1', "::1", "localhost"); // Any host name that isn't your production host. 
$activeDatabaseConnection = 'DB Connection Not Set';
if(in_array($_SERVER['REMOTE_ADDR'], $possibleLocalhosts)) // If our REMOTE_ADDR is in our possibleLocalhosts, it means we're running this code locally. Do this:
{
	// Open a connection with our local database
	$todoAppMySQLConnection = mysqli_connect($local_host, $local_username, $local_password, $local_databaseName);
	// Set our activeDatabaseConnection variable to help with debugging
	$activeDatabaseConnection = "Local DB";
} 
else // If our REMOTE_ADDR wasn't a localhost, we must be working remotely, from our production environment. 
{ 
	// Open a connection with our production database
	$todoAppMySQLConnection = mysqli_connect($remote_host, $remote_username, $remote_password, $remote_databaseName);
	// Set our activeDatabaseConnection variable to help with debugging
	
	$activeDatabaseConnection = "Remote DB";
}
//======================================================================
// DATABASE SCHEMA
//======================================================================
// Following the sample row below, this array should contain any database commands necessary for your database setup. 
$dbSchema = array();
// SAMPLE ROW: $dbSchema['<<short human description>>'] = "<<SQL Code To Execute>>";
$dbSchema['Create Users Table'] =
			"CREATE TABLE USERS ( 
			USER_ID INT NOT NULL AUTO_INCREMENT , 
			EMAIL VARCHAR(255) NOT NULL , 
			QUEST_ID VARCHAR(8) NULL DEFAULT NULL , 
			FIRST_NAME VARCHAR(255) NOT NULL , 
			LAST_NAME VARCHAR(255) NOT NULL , 
			PHONE VARCHAR(255) NULL , 
			IS_PROF INT NOT NULL DEFAULT 0 , 
			IS_ADMIN INT NOT NULL DEFAULT 0 , 
			IS_TA INT NOT NULL DEFAULT 0 , 
			PRIMARY KEY (USER_ID)
		);";

$dbSchema['Create Instructors Table'] = 
		"CREATE TABLE Instructors (
			Instructor_ID int NOT NULL AUTO_INCREMENT,
			Last_Name varchar(255) NOT NULL,
			First_Name varchar(255) NOT NULL,
            User_id int,         
			PRIMARY KEY (Instructor_ID),
			FOREIGN KEY (User_id) REFERENCES Users (User_id) 
		);";
$dbSchema['Create Course_Section Table'] = 
		"CREATE TABLE COURSE_SECTION (
		 	COURSE_ID varchar(255) NOT NULL,
		    SECTION varchar(255) NOT NULL,
		    TERM int NOT NULL,
		    DESCRIPTION varchar(5500) NOT NULL,
		    ENROLLMENT_CAPACITY int NOT NULL, 
		    TITLE varchar(255) NOT NULL,
		    LAB boolean NOT NULL,
		    TUTORIAL boolean NOT NULL,
		    NEEDS_TA boolean DEFAULT FALSE,
			PRIMARY KEY (COURSE_ID, SECTION, TERM)
		);";
$dbSchema['Create Taught_Section Table'] = 
		"CREATE TABLE TAUGHT_SECTION (
		    COURSE_ID varchar(255) NOT NULL,
		    SECTION varchar(255) NOT NULL,
		    TERM int NOT NULL,
		    INSTRUCTOR_ID int NOT NULL,
		    PRIMARY KEY (COURSE_ID, SECTION, TERM, INSTRUCTOR_ID),
		    FOREIGN KEY (COURSE_ID, SECTION, TERM) REFERENCES Course_Section(COURSE_ID, SECTION, TERM),
		    FOREIGN KEY (INSTRUCTOR_ID) REFERENCES Instructors (INSTRUCTOR_ID) 
		);";
$dbSchema['Instructors'] = "INSERT INTO Instructors (First_Name, Last_Name) VALUES ('Kejia','Zhu'),('Olga','Vechtomova'),('Mark','Smucker'),('Frank','Safayeni'),('Mehrdad','Pirnia'),('Selcuk','Onay'),('Jatin','Nathwani'),('Ken','McKay'),('Benny','Mantin'),('Houra','Mahmoudzadeh'),('Bon','Koo'),('Muhammad Shah','Umair'),('Beth','Jewkes'),('Ada','Hurst'),('Qi-Ming','He'),('Mark','Hancock'),('Fatma','Gzara'),('Paul','Guild'),('Bissan','Ghaddar'),('Lukasz','Golab'),('David','Fuller'),('Christina','Fader'),('Fatih Erenay','Safa'),('Samir','Elhedhli'),('Rob','Duimering'),('Stan','Dimitrov'),('Brian Cozzarin','Paul'),('Parmit','Chilana'),('Peter','Carr'),('Jim','Bookbinder'),('Clifford','Blake'),('Minna','Allarakhia'),('Sibel Alev','Alumur'),('Hossein Mehrizi','Abouee'), ('TBD','TBD');";

$dbSchema['Create Form Table'] = 
	"CREATE TABLE FORM (
	FORM_ID INT NOT NULL AUTO_INCREMENT,
	USER_ID INT NOT NULL,
	APPLICATION_TERM VARCHAR(255),
	STUDENT_ID INTEGER NOT NULL,
	LAST_NAME VARCHAR(255) NOT NULL,
	FIRST_NAME VARCHAR(255) NOT NULL,
	UW_USER_ID VARCHAR(20) NOT NULL,
	EMAIL VARCHAR(255) NOT NULL , 
	PHONE VARCHAR(255) NULL , 
	CITIZENSHIP VARCHAR(255),
	PERMIT_EXPIRY DATETIME,
	DEPARTMENT VARCHAR(255) NOT NULL,
	CURRENT_PROGRAM VARCHAR(20) NOT NULL,
	IS_FULL_TIME BOOLEAN NOT NULL DEFAULT FALSE,
	IS_PART_TIME BOOLEAN NOT NULL DEFAULT FALSE,
	EXPECTATIONS BOOLEAN NOT NULL DEFAULT FALSE,
	NEXT_ACADEMIC_TERM VARCHAR(30) NOT NULL,
	TA_POS_PREV_WINTER VARCHAR(255),
	TA_POS_PREV_SPRING VARCHAR(255),
	TA_POS_PREV_FALL VARCHAR(255),
	RELEVANT_COURSES VARCHAR(255),
	COURSES_APPLIED TEXT,
	COURSES_NOT_QUALIFIED VARCHAR(255),
	RELEVANT_EXPERIENCE VARCHAR(255),
	APPLICATION_DATE DATETIME,
	GA_COMMENTS VARCHAR(255),
	GA_VALIDATION VARCHAR(255),
	ACCEPT_REJECT BOOLEAN NOT NULL DEFAULT FALSE,
	PRIMARY KEY (FORM_ID) ); #//until user table is up and running with the login
	#FOREIGN KEY (USER_ID) REFERENCES USERS(USER_ID))";


//========team 3's data========
$dbSchema['Create Login Table'] =
		"CREATE TABLE LOGIN (
		USER_ID INT NOT NULL,
		EMAIL VARCHAR(255) NOT NULL,
		PASS VARCHAR(255) NOT NULL,
		IS_ACTIVE TINYINT(1) NOT NULL,
		PRIMARY KEY (USER_ID)
		);";

//======integrate downstream======
$dbSchema['Create Form Relational Table'] =
		"CREATE TABLE FORM_RELATIONAL (
		FORM_ID INT NOT NULL,
		COURSE_ID VARCHAR(255) NOT NULL,
		SECTION VARCHAR(255) NOT NULL,
		APPLICATION_TERM VARCHAR(255) NOT NULL,
		TA_RANKING INT NOT NULL,
		PROF_RANKING INT NOT NULL DEFAULT 0,
		PRIMARY KEY (FORM_ID, COURSE_ID, SECTION, TA_RANKING)
		);";
//======================================================================
// DEPLOY/UPDATE/RESET DATABASE WIZARD
// To access the wizard, visit db-connection.php?setup-db in your browser.
//======================================================================
?>	
<?php
	if (isset($_GET['wipeAndResetDB'])) // Only enter this if our URL contains a "wipeAndResetDB" parameter
	{	
		echo '<h1>Database Configuration Options (Active Database: ' . $activeDatabaseConnection . ')</h1>';
		// Wipe all tables in database (code modified from http://stackoverflow.com/a/3493398):
		$todoAppMySQLConnection->query('SET foreign_key_checks = 0');
		if ($result = $todoAppMySQLConnection->query("SHOW TABLES"))
		{
		    while($row = $result->fetch_array(MYSQLI_NUM))
		    {
		        $todoAppMySQLConnection->query('DROP TABLE IF EXISTS '.$row[0]);
		    }
		}
		$todoAppMySQLConnection->query('SET foreign_key_checks = 1');
		echo "<table class='table'>";
		echo '<thead><tr><td>Successfully wiped/deleted/droped everything in database.</td></tr></thead>';
		// Execute each of the commands in the $dbSchema array. 
		echo "<tbody>";
		foreach ($dbSchema as $task => $sqlCode) {
			if (mysqli_query($todoAppMySQLConnection, $sqlCode)) {
				echo '<tr><td><pre>Success: ' . $task . '</pre></td></tr>';
			} else {
				echo '<tr><td><pre>Error: ' . $task . ' | ' . mysqli_error($todoAppMySQLConnection) . '</pre></td></tr>';
			}
		}
		echo '<tr><td> All dbSchema tasks have been completed.</td></tr></tbody></table>';
	}
	?>