<html>
<head>
	<title>Stubbing</title>
</head>
<body>
<table width="100%" border="1px" cellpadding="5" cellspacing="0">	
<thead>
	<tr>
		<th>COURSE_ID</th>
		<th>SECTION</th>
		<th>TERM</th>
		<th>DESCRIPTION</th>
		<th>ENROLLMENT_CAPACITY</th>
		<th>TITLE</th>
		<th>LAB</th>
		<th>TUTORIAL</th>
		<th>NEEDS_TA</th>
	</tr>
</thead>
<tbody>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
	// Include Database Connection:
	// echo "start";
	include 'db-connection.php';
	// echo "successful";
		// Query db for all tasks:
		$query_ListAllcourse = "SELECT * FROM course_section;";
		$result_Allcourse = mysqli_query($todoAppMySQLConnection, $query_ListAllcourse);
		// echo "The following courses are in the course_section table.";
		while($singleCourse = mysqli_fetch_assoc($result_Allcourse)) {
			    	echo '<tr>';
			    	echo '<td>'.$singleCourse['COURSE_ID'] . '</td>' ;
			    	echo '<td>'.$singleCourse['SECTION'] . '</td>' ;
			    	echo '<td>'.$singleCourse['TERM'] . '</td>' ;
			    	echo '<td>'.$singleCourse['DESCRIPTION'] . '</td>' ;
			    	echo '<td>'.$singleCourse['ENROLLMENT_CAPACITY'] . '</td>' ;
			    	echo '<td>'.$singleCourse['TITLE'] . '</td>' ;
			    	echo '<td>'.$singleCourse['LAB'] . '</td>' ;
			    	echo '<td>'.$singleCourse['TUTORIAL'] . '</td>' ;
			    	echo '<td>'.$singleCourse['NEEDS_TA'] . '</td>' ;
			    	echo '</tr>';
			    }
		?>
		</tbody>
	</table>
</body>
</html>


